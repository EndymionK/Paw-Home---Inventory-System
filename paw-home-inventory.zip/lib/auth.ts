// Simple authentication context for the Paw & Home system
export interface User {
  id: string
  username: string
  role: "admin"
}

// Mock user data - in a real app this would come from a database
const ADMIN_USERS = [
  { id: "1", username: "admin", password: "admin123", role: "admin" as const },
  { id: "2", username: "pawadmin", password: "paw2024", role: "admin" as const },
]

export async function authenticateUser(username: string, password: string): Promise<User | null> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  const user = ADMIN_USERS.find((u) => u.username === username && u.password === password)
  if (user) {
    return { id: user.id, username: user.username, role: user.role }
  }
  return null
}

export function isAuthenticated(): boolean {
  if (typeof window === "undefined") return false
  return localStorage.getItem("paw-auth-user") !== null
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null
  const userData = localStorage.getItem("paw-auth-user")
  return userData ? JSON.parse(userData) : null
}

export function setAuthUser(user: User): void {
  localStorage.setItem("paw-auth-user", JSON.stringify(user))
}

export function logout(): void {
  localStorage.removeItem("paw-auth-user")
}
